# Password-Cracker-v3.0
Crack any Facebook, Instagram, Discord etc accounts with this script

Install

1. Install python 3 on your computer or VPS
2. Install the imported modules - mechanize, itertools
    pip install ...
3. Edit the file variables - username and the lenght of the password
4. Run the script python password_bruteforce_v3.0.py
 
Enjoy! :P
